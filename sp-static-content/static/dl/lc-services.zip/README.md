# lc services

these are variants of lc services provided as fully executable jars. fully executable in terms of executing

```
java -jar lc-service.jar
```

Or you can install them as service on linux to use commands like 

```
service lc-service start|stop|...
```

How to install them as serivce consult https://docs.spring.io/spring-boot/docs/current/reference/html/deployment.html#deployment.installing

To configure the service, just edit the provided `application.properties` beneath the jar file.
